cat example.dict | ./hashcat.bin -m 400 example400.hash
